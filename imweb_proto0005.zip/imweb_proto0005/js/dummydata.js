
// 사전교육 영상 주소 

// 동영상 주소 
var src = {
	// html
	"1강": "https://www.youtube.com/embed/tZooW6PritE",
	"2강": "https://www.youtube.com/embed/Z7uBInm1PJY",
	"3강": "https://www.youtube.com/embed/QwCdCcsPVTQ",
	"4강1": "https://www.youtube.com/embed/MLXlXCwA0T4",
	"4강2": "https://www.youtube.com/embed/MLXlXCwA0T4",

	//java
	"Java 1강": "https://www.youtube.com/embed/MLXlXCwA0T4",
	"Java 2강": "https://www.youtube.com/embed/6eB4a0Nj9wo",
}

// 페이지 header
var dummyData = {
	"1강": "<div>playdata 온라인 사전교육 : html</div>",
	"2강": "<div>playdata 온라인 사전교육 : html</div>",
	"3강": "<div>playdata 온라인 사전교육 : html</div>",
	"4강1": "<div>playdata 온라인 사전교육 : html</div>",
	"Java 1강": "<div>playdata 온라인 사전교육 : Java</div>",
	"Java 2강": "<div>playdata 온라인 사전교육 : Java</div>"
}