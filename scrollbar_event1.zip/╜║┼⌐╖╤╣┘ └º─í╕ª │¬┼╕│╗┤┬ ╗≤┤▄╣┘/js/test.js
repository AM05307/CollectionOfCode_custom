$(window).on('scroll', function(){
   	var currentPercentage = ($(window).scrollTop() / ($(document).outerHeight() - $(window).height())) * 100;
 		$('#i-am-progress-indicator').width(currentPercentage+'%');
});


<script type="text/javascript">
jQuery(window).on('scroll', function(){
   	var currentPercentage = (jQuery(window).scrollTop() / (jQuery(document).outerHeight() - jQuery(window).height())) * 100;
 		jQuery('#i-am-progress-indicator').width(currentPercentage+'%');
});
</script>

